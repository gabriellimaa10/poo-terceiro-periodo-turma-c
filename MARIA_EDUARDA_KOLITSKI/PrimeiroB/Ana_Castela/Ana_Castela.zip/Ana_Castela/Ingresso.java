package Dona_Gabi.Ana_Castela;

public class Ingresso {
    private Integer id;

}
